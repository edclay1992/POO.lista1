﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex06
{
    internal class Milha
    {

        private double valor1;
        private double resultado;

        public void setValor(double valor)
        {
            valor1 = valor;
        }
        public double getValor()
        {
            return valor1;
        }
        public void operacao()
        {
            resultado = valor1 * 1852;
        }
        public double getResultado()
        {
            return resultado;
        }


    }
}
