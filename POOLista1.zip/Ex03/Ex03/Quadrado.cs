﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex03
{
    internal class Quadrado
    {
        private double d1;
        private double l2;
        private double resultado;

        public void setD1(double d)
        {
            d1 = d;
        }
        public void setL2(double l)
        {
            l2 = l;
        }
        public double getD1()
        {
            return d1;
        }
        public double getL2()
        {
            return l2;
        }
        public double getResultado()
        {
            return resultado;
        }
        public void operacaolado()
        {
            l2 = d1 / Math.Sqrt(2);
        }
        public void operacao()
        {
            resultado = Math.Pow(l2, 2);
        }


    }
}
