﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex07
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Dolar dolar1;
            dolar1 = new Dolar();

            Console.WriteLine("Digite o Valor da Cotação do Dólar: R$ ");
            dolar1.setValor1(double.Parse(Console.ReadLine()));
            Console.WriteLine("Digite um Valor em Dólares: US$ ");
            dolar1.setValor2(double.Parse(Console.ReadLine()));

            dolar1.operacao();

            Console.WriteLine("Resultado em reais: R${0}", dolar1.getResultado());



        }
    }
}
