﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex09
{
    internal class Comparacao02
    {

        private double v1;
        private double v2;
        private string m;

        public void setV1(double v)
        {
            v1 = v;
        }
        public void setV2(double v)
        {
            v2 = v;
        }
        public double getV2()
        {
            return v2;
        }
        public double getV1()
        {
            return v1;
        }
        public void compara()
        {
            if (v1 > v2)
            {
                m = "1º";
            }
            if (v1 < v2)
            {
                m = "2º";
            }
            else
            if (v1 == v2)
            {
                m = "Ambos os valores são iguais";
            }
        }
        
        public string getM()
        {
            return m;
        }



    }
}

