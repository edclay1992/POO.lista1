﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Terreno terreno1;
            terreno1 = new Terreno();

            Console.WriteLine("Obtenha a definição do seu retangulo a partir deste software");
            Console.WriteLine("Digite a area");
            terreno1.setA1(double.Parse(Console.ReadLine()));
            Console.WriteLine("Digite a base");
            terreno1.setB2(double.Parse(Console.ReadLine()));


            terreno1.operacao();
            terreno1.tp();
            terreno1.tg();


            Console.WriteLine("{0}", terreno1.getResultado());

        }
    }
}
