﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pprojRetanguloPOO
{
    internal class Retangulo
    {

        private int n1;
        private int b2;
        private int area;

        public void setN1(int a)
        {
            n1 = a;
        }
        public void setB2(int b)
        {
            b2 = b;
        }
        public int getN1()
        {
            return n1;
        }
        public int getB2()
        {
            return b2;
        }
        public int getArea()
        {
            return area;
        }
        public void Multiplicar()
        {
            area = n1 * b2;
        }




    }
}
